<?php include db.php;?>

<?php

function queryConfirm($result){
    global $connection;
 if(!$result){
        
        die("Query Failed  ".mysqli_error($connection));
    }
    
}




function searchData(){

                                    
                                    if(isset($_POST['submit'])){
                                     $search= $_POST['search'];
                                        $query="SELECT * FROM post WHERE post_tag LIKE '%$search%'";
                                        $search_query=mysqli_query($connection,$query);
                                        if(!$search_query){
                                            
                                         die("Query Failed".mysql_error($connection));   
                                            
                                        }
                                        $count = mysqli_num_rows($search_query);
                                        if ($count==0){
                                            
                                          echo "<hi>NO RE RESULT</h1>";  
                                        } else
                                          {
                                            echo "SOME RESULTS";
                                            
                                        }
                                    }
                                    else{
                                    echo "Search item not found";
                                    }
                                    
                                    
                                   
}




?>