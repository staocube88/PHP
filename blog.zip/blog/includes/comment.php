
              
<?php
if(isset($_POST['createcomment'])){
    $te_post_id =$_GET['p_id'];
    
    $comment_author = $_POST['comment_author'];
    $comment_email = $_POST['comment_email'];
    $comment_content = $_POST['comment_content'];
    /*$comment_status = 'Draft';
    $comment_date =date('d-m-y');
    $comment_image =$_FILES['comment_image']['name'];
    $comment_image_temp =$_FILES['comment_image']['tmp_name'];
    

    
    move_uploaded_file($post_image_temp, "../assets/img/comment/comment.png");*/
    
    
    
    $query="INSERT INTO comments (comment_post_id,comment_author,comment_email,comment_content,comment_status,comment_date,comment_image)";
    $query.="VALUES ('{$te_post_id}','{$comment_author}','{$comment_email}','{$comment_content}','UNAPPROVED',now(),'comment.png')";
    $comment_query=mysqli_query($connection, $query);
   // queryConfirm($comment_query);
    
    
    
    $query="UPDATE post SET post_comment_count=post_comment_count + 1
    WHERE post_id=$te_post_id";
    $updatecommentcount=mysqli_query($connection, $query);
    
}


?>
              
              
                    <?php
                  // if(isset($_GET['p_id'])){
                       
                 //      $the_comment_id = $_GET['p_id'];
                 //  }
                   
                   $query="SELECT * FROM comments WHERE comment_post_id={$te_post_id}
                      AND comment_status='Approved'
                      ORDER BY comment_id DESC ";
                   $select_comment=mysqli_query($connection, $query);
                   if(!$select_comment){
                       die("QUERY FAILED ".mysqli_error($connection));
                       
                   }
                   while($row=mysqli_fetch_assoc($select_comment)){
                     //  $the_comment_id=$row['comment_id'];
                       $comment_image=$row['comment_image'];
                       $comment_author=$row['comment_author'];
                       $comment_date=$row['comment_date'];
                       $comment_content=$row['comment_content'];               
                                      
                   ?>
               <div class="comments-area">
                
                 <h4>05 Comments</h4>
                  <div class="comment-list">
                     <div class="single-comment justify-content-between d-flex">
                        <div class="user justify-content-between d-flex">
                           <div class="thumb">
                              <img src="assets/img/comment/<?php echo $comment_image;?>" alt="">
                           </div>
                           <div class="desc">
                              <p class="comment">
                                 <?php echo $comment_content; ?>
                              </p>
                              <div class="d-flex justify-content-between">
                                 <div class="d-flex align-items-center">
                                    <h5>
                                       <a href="#"><?php echo $comment_author; ?></a>
                                    </h5>
                                    <p class="date"><?php echo $comment_date;?> </p>
                                 </div>
                                 <div class="reply-btn">
                                    <a href="#" class="btn-reply text-uppercase">reply</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <?php } ?>
               <div class="comment-form">
                  <h4>Leave a Comment</h4>
                  <form class="form-contact comment_form" action="" method="post" id="commentForm">
                     <div class="row">
                        <div class="col-12">
                           <div class="form-group">
                            
                              <textarea class="form-control w-100" name="comment_content" id="comment" cols="30" rows="9"
                                 placeholder="Write Comment"></textarea>
                           </div>
                        </div>
                        <div class="col-sm-6">
                           <div class="form-group">
                              <input class="form-control" name="comment_author" id="name" type="text" placeholder="Name">
                           </div>
                        </div>
                        <div class="col-sm-6">
                           <div class="form-group">
                              <input class="form-control" name="comment_email" id="email" type="email" placeholder="Email">
                           </div>
                        </div>
                       
                     </div>
                     <div class="form-group">
                        <button type="submit" name="createcomment" class="button button-contactForm btn_1 boxed-btn">Post Comment</button>
                     </div>
                  </form>
               </div>