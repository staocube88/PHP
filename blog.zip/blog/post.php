<?php include"includes/header.php";?>
    <?php include"includes/db.php";?>

    <?php include"includes/navigation.php";?>
     
   <!--================Blog Area =================-->
   <section class="blog_area single-post-area section-padding">
      <div class="container">
         <div class="row">
            <div class="col-lg-8 posts-list">
              
               <?php
                
                if(isset($_GET['p_id']))
                {
                    $te_post_id=$_GET['p_id'];
                }
                
                $query="SELECT * FROM post WHERE post_id =$te_post_id";
                
                $select_all = mysqli_query($connection, $query);
             //   queryConfirm($select_all_post_query);
                                           while($row = mysqli_fetch_assoc($select_all)){
                                               $te_post_id =$row['post_id'];
                                               $post_title =$row['post_title'];
                                               $post_cat_id=$row['post_cat_id'];
                                               $post_author =$row['post_author'];
                                               $post_date =$row['post_date'];
                                               $post_image =$row['post_image'];
                                               $post_content =$row['post_content'];
                                               $post_comment_count =$row['post_comment_count'];
                                               
                                                                                             
                                               
                                               ?>
              
              
               <div class="single-post">
                  <div class="feature-img">
                     <img class="img-fluid" src="assets/img/news/<?php echo $post_image; ?>" alt="">
                  </div>
                  <div class="blog_details">
                     <h2><?php echo $post_title;?>
                     </h2>
                     <ul class="blog-info-link mt-3 mb-4">
                        <li><a href="#" >  <i class="fa fa-user"></i>  <?php
                       
                        $query="SELECT * FROM categories WHERE id ={$post_cat_id}";
                                                $select_catt = mysqli_query($connection, $query);
                 
                                                while($row = mysqli_fetch_assoc($select_catt)){
                                               $cat_id =$row['id'];
                                               $cat_title =$row['cat_title'];
                                                 echo $cat_title;
                                                  }
                        ?></a></li>
                        <li><a href="#"><i class="fa fa-comments"></i> <?php echo $post_comment_count; ?> Comments</a></li>
                        <li><a href="#"><i class="fa fa-date"></i> <?php echo $post_date; ?></a></li>
                      </ul>
                     <p class="excert">
                        <?php echo $post_content; ?>
                     </p>
                     
                  </div>
               </div>
               <div class="navigation-top">
                  <div class="d-sm-flex justify-content-between text-center">
                     <p class="like-info"><span class="align-middle"><i class="fa fa-heart"></i></span> Lily and 4
                        people like this</p>
                     <div class="col-sm-4 text-center my-2 my-sm-0">
                        <!-- <p class="comment-count"><span class="align-middle"><i class="fa fa-comment"></i></span> 06 Comments</p> -->
                     </div>
                     <ul class="social-icons">
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-dribbble"></i></a></li>
                        <li><a href="#"><i class="fab fa-behance"></i></a></li>
                     </ul>
                  </div>
                  <div class="navigation-area">
                     <div class="row">
                        <div
                           class="col-lg-6 col-md-6 col-12 nav-left flex-row d-flex justify-content-start align-items-center">
                           <div class="thumb">
                              <a href="#">
                                 <img class="img-fluid" src="assets/img/post/preview.png" alt="">
                              </a>
                           </div>
                           <div class="arrow">
                              <a href="#">
                                 <span class="lnr text-white ti-arrow-left"></span>
                              </a>
                           </div>
                           <div class="detials">
                              <p>Prev Post</p>
                              <a href="#">
                                 <h4>Space The Final Frontier</h4>
                              </a>
                           </div>
                        </div>
                        <div
                           class="col-lg-6 col-md-6 col-12 nav-right flex-row d-flex justify-content-end align-items-center">
                           <div class="detials">
                              <p>Next Post</p>
                              <a href="#">
                                 <h4>Telescopes 101</h4>
                              </a>
                           </div>
                           <div class="arrow">
                              <a href="#">
                                 <span class="lnr text-white ti-arrow-right"></span>
                              </a>
                           </div>
                           <div class="thumb">
                              <a href="#">
                                 <img class="img-fluid" src="assets/img/post/next.png" alt="">
                              </a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="blog-author">
                  <div class="media align-items-center">
                     <img src="assets/img/blog/author.png" alt="">
                     <div class="media-body">
                        <a href="#">
                           <h4><?php echo $post_author; ?></h4>
                        </a>
                        <p>Second divided from form fish beast made. Every of seas all gathered use saying you're, he
                           our dominion twon Second divided from</p>
                     </div>
                  </div>
               </div>
              <?php include"includes/comment.php";?>
            </div>
            <?php } ?>
            
            
             
           <?php include"includes/sidebar.php";?>
         </div>
      </div>
   </section>
   <!--================ Blog Area end =================-->
<?php include"includes/footer.php";?>
  
   
<!-- JS here -->
	
		