<?php include "includes/admin_header.php" ?>
 
   <div class="page-container">
   <!--/content-inner-->
<div class="left-content">
	   <div class="mother-grid-inner">
             <!--header start here-->
				<?php include "includes/nav.php"?>
<!--heder end here-->
		<ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a> <i class="fa fa-angle-right"></i></li>
            </ol>
            
            
            
            <!--BODY begins-->
            
            
                <div class="col-xs-6">
           
              
               <?php insertcat(); ?>
               
                
                
                <form action="" method="post">
                    <div class="form-group">
                        <label for="cat_title">Add Category</label>
                    <input class="form-control" type="text" name="cat_title">
                    </div>
                    <div class="form-group">
                        <input class="btn btn-primary" type="submit" name="submit" value="Add Category">
                    </div>            
                    </form>
                    
                    
                    
                    
                    <?php
                    if(isset($_GET['update'])){
                        $cat_id=$_GET['update'];
                        
                        include "includes/updatecat.php";
                    }
                    ?>
                    
                                  
                    
           </div>
            
            
            <div class="col-xs-6">
              
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Category Title</th>
                            <th>Delete</th>
                            <th>Update</th>
                        </tr>
                    </thead>
                    <tbody>
                       <!--FIND ALL CATEGORY-->
                       <?php findcat(); ?>
                                           
                                           <!--DELETE QUERY-->
                                           <?php deletecat(); ?>
                                      
                                           
                        </tbody>
                </table>
           </div>
            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
                        <!--BODY ends-->

	  <!--//w3-agileits-pane-->	
<!-- script-for sticky-nav -->
		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop(); 
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });
			 
		});
		</script>
		<!-- /script-for sticky-nav -->
<!--inner block start here-->
<div class="inner-block">

</div>
<!--inner block end here-->
<!--copy rights start here-->

<!--COPY rights end here-->
</div>
</div>
  <!--//content-inner-->
			<!--/sidebar-menu-->
				
                          <?php include "includes/sidebar.php"?>
                          
                          
							  <div class="clearfix"></div>		
							</div>
							<script>
							var toggle = true;
										
							$(".sidebar-icon").click(function() {                
							  if (toggle)
							  {
								$(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
								$("#menu span").css({"position":"absolute"});
							  }
							  else
							  {
								$(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
								setTimeout(function() {
								  $("#menu span").css({"position":"relative"});
								}, 400);
							  }
											
											toggle = !toggle;
										});
							</script>
<!--js -->
<?php include "includes/admin_footer.php" ?>