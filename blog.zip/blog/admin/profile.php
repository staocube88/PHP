<?php include "includes/admin_header.php" ?>

<?php
    if(isset($_SESSION['username'])){
       
        $username =$_SESSION['username'];
        $query = "SELECT * FROM users WHERE username ='{$username}'";
        $profilequery=mysqli_query($connection, $query);
        while($row = mysqli_fetch_array($profilequery)){
            
                                                $user_id =$row['user_id'];
                                               $username =$row['username'];
                                               $password =$row['password'];
                                               $user_fname =$row['user_fname'];
                                               $user_lname =$row['user_lname'];
                                               $user_desc =substr($row['user_desc'], 0, 100);
                                               $user_email =$row['user_email'];
                                               $user_image =$row['user_image'];  
                                               $user_role =$row['user_role'];
                                               $randSalt =$row['randSalt'];
        }
        
    }
?>

<?php
if(isset($_POST['updateprofile'])){ 
                                
                                 $username =$_POST['username'];
                                 $password =$_POST['password'];
                                 $user_fname =$_POST['user_fname'];
                                 $user_lname =$_POST['user_lname'];
                                 $user_desc =$_POST['user_desc'];
                                 $user_email =$_POST['user_email'];
                                 $user_image =$_FILES['user_image']['name'];
                                 $user_image_temp =$_FILES['user_image']['tmp_name']; 
                                 $user_role =$_POST['user_role'];
                              //   $randSalt =$_POST['randSalt'];
                                                 
    move_uploaded_file($user_image_temp, "../assets/img/user/$user_image");
    //$hashFormat="$2y$10$";
//$salt="qwertyaiuygghuhiuiuiotmnb94";
//$hashF_and_salt=$hashFormat.$salt;
//$password=crypt($password,$hashF_and_salt);
                                               
                                    if(empty($user_image)) {
                                       $query="SELECT * FROM users WHERE username=$username";
                                        $selectpp_image=mysqli_query($connection, $query);
                                        while($row =mysqli_fetch_array($selectpp_image))
                                        {
                                            $user_image = $row['user_image'];
                                        }
                                                                  
                                        
                                    }          
                                    
                                            $query="
                                            UPDATE users 
                                            SET 
                                                username ='$username',
                                                password ='$password',
                                                user_fname ='$user_fname',
                                                user_lname ='$user_lname',
                                                user_desc ='$user_desc',
                                                user_email ='$user_email',
                                                user_image ='$user_image',
                                                user_role ='$user_role'
                                               WHERE username ='$username'";
                            $updatep_post_query=mysqli_query($connection, $query);
                            queryConfirm($updatep_post_query);
                            header("Location: user.php");
}
                            

?>
 
   <div class="page-container">
   <!--/content-inner-->
<div class="left-content">
	   <div class="mother-grid-inner">
             <!--header start here-->
				<?php include "includes/nav.php"?>
<!--heder end here-->
		<ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a> <i class="fa fa-angle-right"></i></li>
            </ol>
            
            
            
            <!--BODY begins-->
        <div class ="container-fluid">    
             <form action="" method="post" enctype="multipart/form-data">                  
                  
                  <div class="form-group">
                        <label for="post_date">First Name</label>
                    <input class="form-control" type="text" value="<?php echo $user_fname;?>" name="user_fname">
                    </div>
                     <div class="form-group">
                        <label for="post_date">Last Name</label>
                    <input class="form-control" type="text" value="<?php echo $user_lname;?>" name="user_lname">
                    </div>
                   
                    <div class="form-group">
                        <label for="username">Username</label>
                    <input class="form-control" type="text" value="<?php echo $username;?>" name="username">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                    <input class="form-control" type="password" value="<?php echo $password;?>" name="password">
                    </div>
                    <div class="form-group">
                        <label for="user_role">Edit User</label>
                   <select name="user_role" id="">
                           <option value="Subscriber"> <?php echo $user_role; ?></option> 
                                      
                            <option value="Admin"> Admin</option> 
                            <option value="Subscriber"> Subscriber</option>                
                        </select>            
                    </div>
                    
                    <div class="form-group">
                        <label for="post_content">About User</label>
                        <textarea class="form-control" id="" cols="30" rows="10" name="user_desc" ><?php echo $user_desc;?></textarea>
                    </div>
                     <div class="form-group">
                        <label for="user_email">Email Address </label>
                    <input class="form-control" type="email" value="<?php echo $user_email;?>" name="user_email">
                    </div>
                    <div class="form-group">
                        <label for="user_image">User Image</label>
                    <img src="../assets/img/user/<?php echo $user_image;?>" alt="Post Image" width="100">
                    <input class="form-control" type="file" name="user_image">
                    </div> 
                  
                    <div class="form-group">
                        <input class="btn btn-primary" type="submit" name="updateprofile" value="Update profile">
                    </div>            
                    </form>
                   
           </div>
            
            
            
            
            
            
            
            
            
            
            
            
            
                        <!--BODY ends-->

	  <!--//w3-agileits-pane-->	
<!-- script-for sticky-nav -->
		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop(); 
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });
			 
		});
		</script>
		<!-- /script-for sticky-nav -->
<!--inner block start here-->
<div class="inner-block">

</div>
<!--inner block end here-->
<!--copy rights start here-->

<!--COPY rights end here-->
</div>
</div>
  <!--//content-inner-->
			<!--/sidebar-menu-->
				
                          <?php include "includes/sidebar.php"?>
                          
                          
							  <div class="clearfix"></div>		
							</div>
							<script>
							var toggle = true;
										
							$(".sidebar-icon").click(function() {                
							  if (toggle)
							  {
								$(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
								$("#menu span").css({"position":"absolute"});
							  }
							  else
							  {
								$(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
								setTimeout(function() {
								  $("#menu span").css({"position":"relative"});
								}, 400);
							  }
											
											toggle = !toggle;
										});
							</script>
<!--js -->
<?php include "includes/admin_footer.php" ?>