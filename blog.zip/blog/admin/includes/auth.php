<?php  include "db.php";?>
<?php  session_start();?>
<?php 
  // global $connection;
    
 if(isset($_POST['auth'])){
        
       $username= $_POST['username'];
        $password=$_POST['password']; $username=mysqli_real_escape_string($connection,$username); $password=mysqli_real_escape_string($connection,$password);
        
        $query = "SELECT * FROM users WHERE username='{$username}' ";
        $login_query=mysqli_query($connection,$query);

if(!$login_query){
	die("Query Failed". mysqli_error($connection));
}
        
while($row = mysqli_fetch_assoc($login_query)){
	$db_user_id= $row['user_id'];
    $db_username= $row['username'];
    $db_password= $row['password'];
    $db_user_fname= $row['user_fname'];
    $db_user_lname= $row['user_lname'];
    $db_user_role= $row['user_role'];
	}
	
if($username !== $db_username && $password !== $db_password){
         header("Location: ../index.php");
}
 else if($username == $db_username && $password == $db_password){
             $_SESSION['username'] = $db_username;
             $_SESSION['user_fname'] = $db_user_fname;
             $_SESSION['user_lname'] = $db_user_lname;
             $_SESSION['user_role'] = $db_user_role;
     
            header("Location: ../dashboard.php");
            
 }       
else{
        
         header("Location: ../errorpage.php");
       
}


}



?>


