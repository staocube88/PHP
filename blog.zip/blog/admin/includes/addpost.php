
<?php
if(isset($_POST['createpost'])){
                                               $post_cat_id =$_POST['post_category'];
                                               $post_title =$_POST['post_title'];
                                               $post_author =$_POST['post_author'];
                                               $post_image =$_FILES['post_image']['name'];
                                               $post_image_temp =$_FILES['post_image']['tmp_name'];
                                               $post_content =$_POST['post_content'];
                                               $post_tag =$_POST['post_tag'];
                                               $post_status =$_POST['post_status'];
                                               $post_type =$_POST['post_type'];
                                               $post_view =4;
                                          //  $post_comment_count =4;
                                               $post_date =date('d-m-y');
    
    move_uploaded_file($post_image_temp, "../assets/img/news/$post_image");
    
    $query="INSERT INTO post (post_cat_id,post_title,post_author,post_date,post_image,post_content,post_tag,post_status,post_type,post_view)";
    $query.= "VALUES('{$post_cat_id}','{$post_title}','{$post_author}','{$post_date}','{$post_image}','{$post_content}','{$post_tag}','{$post_status}','{$post_type}','{$post_view}')"; 
    
    $createpost_query=mysqli_query($connection, $query);
    
   queryConfirm($createpost_query);
}

?> 
                   
                   
                   <form action="" method="post" enctype="multipart/form-data">
                   <div class="form-group">
                        <label for="post_cat_id">Post Category Id</label>
                   <select name="post_category" id="">
                       <?php
                       
                        $query="SELECT * FROM categories";
                $select_cate = mysqli_query($connection, $query);
                             queryConfirm($select_cate);            
                                           while($row = mysqli_fetch_assoc($select_cate)){
                                               $cat_id =$row['id'];
                                               $cat_title =$row['cat_title'];
                                            
                                               echo "<option value='$cat_id'>{$cat_title}</option>";  
                                               
                                           }
                        ?>
                   </select>
                    </div>
                 <!--   <div class="form-group">
                        <label for="post_cat_id">Post Category Id</label>
                    <input class="form-control" type="text" name="post_cat_id">
                    </div>-->
                    <div class="form-group">
                        <label for="post_title">Post Title</label>
                    <input class="form-control" type="text" name="post_title">
                    </div>
                    <div class="form-group">
                        <label for="post_author">Post Author</label>
                    <input class="form-control" type="text" name="post_author">
                    </div>
                    <div class="form-group">
                        <label for="post_date">Post Date</label>
                    <input class="form-control" type="date" name="post_date">
                    </div>
                    <div class="form-group">
                        <label for="post_image">Post Image</label>
                    <input class="form-control" type="file" name="post_image">
                    </div> 
                    <div class="form-group">
                        <label for="post_content">Post Content</label>
                        <textarea class="form-control" id="" cols="30" rows="10" name="post_content"></textarea>
                    </div>
                     <div class="form-group">
                        <label for="post_tag">Post Tag</label>
                    <input class="form-control" type="text" name="post_tag">
                    </div>
                     <div class="form-group">
                        <label for="post_type">Post Type</label>
                    <input class="form-control" type="text" name="post_type" placeholder="Trending/Recent/Weekly/Flash">
                    </div>
                    <div class="form-group">
                        <label for="post_status">Post Status</label>
                    <input class="form-control" type="text" name="post_status" placeholder="Draft/Publish">
                    </div>
                                      
                    <div class="form-group">
                        <input class="btn btn-primary" type="submit" name="createpost" value="Add New Post">
                    </div>            
                    </form>