
<?php
function insertcat()   
{
    global $connection;
    
                    if(isset($_POST['submit'])){
                        
                     $cat_title =$_POST['cat_title'];
                        
                        if($cat_title=="" || empty($cat_title)){
                            
                            echo "this field shouldn't be empty";
                            
                        }else{
                            
                            $query= "INSERT INTO categories (cat_title)";
                            $query.= "VALUE ('{$cat_title}')";
                            $create_cat=mysqli_query($connection, $query);
                            if(!$create_cat){
                                die('Query Failed '.mysqli_error($connection));
                                
                            }
                        }
                        
                    }
                
    
}

function findcat(){
    global $connection;
    $query="SELECT * FROM categories";
                $select_cat_query = mysqli_query($connection, $query);
                 
                                           while($row = mysqli_fetch_assoc($select_cat_query)){
                                               $cat_id =$row['id'];
                                               $cat_title =$row['cat_title'];
                                          echo  "<tr>";
                                                 echo "<td>{$cat_id}</td>";
                                              echo "<td>{$cat_title}</td>"; 
                                               echo "<td><a href='categories.php?delete={$cat_id}'><i class='fa fa-close'></i></a></td>"; 
                                            echo "<td><a href='categories.php?update={$cat_id}'><i class='fa fa-pencil'></i></a></td>"; 

                                               echo "<tr>";
                                           }           
}


function findpost(){
    global $connection;
    $query="SELECT * FROM post";
                $select_post_query = mysqli_query($connection, $query);
                 
                                           while($row = mysqli_fetch_assoc($select_post_query)){
                                               $post_id =$row['post_id'];
                                               $post_cat_id =$row['post_cat_id'];
                                               $post_title =$row['post_title'];
                                               $post_author =$row['post_author'];
                                               $post_image =$row['post_image'];
                                               $post_content =substr($row['post_content'],0,100);
                                               $post_tag =$row['post_tag'];
                                               $post_status =$row['post_status'];
                                               $post_view =$row['post_view'];
                                               $post_date =$row['post_date'];
                                                echo  "<tr>";
                                               
                                               
                                                $query="SELECT * FROM categories WHERE id ={$post_cat_id}";
                                                $select_catt = mysqli_query($connection, $query);
                 
                                                while($row = mysqli_fetch_assoc($select_catt)){
                                               $cat_id =$row['id'];
                                               $cat_title =$row['cat_title'];
                                                 echo "<td>{$cat_title}</td>";
                                                  }
                                           //   echo "<td>{$post_cat_id}</td>";  
                                              echo "<td>{$post_title}</td>"; 
                                               echo "<td>{$post_author}</td>";
                                              echo "<td><img width='100'' src='../assets/img/news/{$post_image}'></td>"; 
                                                 echo "<td>{$post_content}</td>";
                                              echo "<td>{$post_tag}</td>"; 
                                                 echo "<td>{$post_status}</td>";
                                              echo "<td>{$post_view}</td>"; 
                                               echo "<td>{$post_date}</td>"; 
                                               echo "<td><a href='post.php?delete={$post_id}'><i class='fa fa-close'></i></a></td>"; 
                                            echo "<td><a href='post.php?source=updatepost&p_id={$post_id}'><i class='fa fa-pencil'></i></a></td>"; 
                                               echo "<tr>";
                                           }           
}


function finduser(){
    global $connection;
    $query="SELECT * FROM users";
    $select_user_query = mysqli_query($connection, $query);
                 
                                           while($row = mysqli_fetch_assoc($select_user_query)){
                                               $user_id =$row['user_id'];
                                               $username =$row['username'];
                                               $password =$row['password'];
                                               $user_fname =$row['user_fname'];
                                               $user_lname =$row['user_lname'];
                                               $user_desc =substr($row['user_desc'], 0, 100);
                                               $user_email =$row['user_email'];
                                               $user_image =$row['user_image'];  
                                               $user_role =$row['user_role'];
                                               $randSalt =$row['randSalt'];
                                               
                                            
                                                echo  "<tr>";
                                              echo "<td>{$user_id}</td>";  
                                              echo "<td><img width='100'' src='../assets/img/user/{$user_image}'></td>"; 
                                              echo "<td>{$username}</td>"; 
                                           //    echo "<td>{$password}</td>";
                                              echo "<td>{$user_fname}</td>";
                                               echo "<td>{$user_lname}</td>";
                                               echo "<td>{$user_desc}</td>";
                                               echo "<td>{$user_email}</td>"; 
                                               echo "<td>{$user_role}</td>";
                                               echo "<td><a href='user.php?makeadmin={$user_id}'><i class='fa fa-check'></i></a></td>";
                                               echo "<td><a href='user.php?makesubscriber={$user_id}'><i class='fa fa-ban'></i></a></td>"; 
                                               echo "<td><a href='user.php?delete={$user_id}'><i class='fa fa-close'></i></a></td>"; 
                                            echo "<td><a href='user.php?source=updateuser&p_id={$user_id}'><i class='fa fa-pencil'></i></a></td>"; 
                                               echo "<tr>";
                                                      
      
      }
                                                            }
                                                





function findcomment(){
    global $connection;
    $query="SELECT * FROM comments";
                $select_comment_query = mysqli_query($connection, $query);
                 
                                           while($row = mysqli_fetch_assoc($select_comment_query)){
                                               $comment_id =$row['comment_id'];
                                               $comment_post_id =$row['comment_post_id'];
                                               $comment_author =$row['comment_author'];
                                               $comment_email =$row['comment_email'];
                                               $comment_content =substr($row['comment_content'],0,100);
                                                $comment_status =$row['comment_status']; 
                                               $comment_date =$row['comment_date'];
                                               $comment_image =$row['comment_image'];
                                               
                                           
                                                echo  "<tr>";
                                               
                                               
                                                echo "<td>{$comment_id}</td>"; 
                                              echo "<td><img width='100'' src='../assets/img/comment/{$comment_image}'></td>"; 
                                                echo "<td>{$comment_author}</td>";
                                                 echo "<td>{$comment_content}</td>";
                                              echo "<td>{$comment_email}</td>"; 
                                                 echo "<td>{$comment_status}</td>";
                                              echo "<td>{$comment_date}</td>"; 
                                               
                                               $query="SELECT * FROM post WHERE post_id ={$comment_post_id}";
                                                $select_commen = mysqli_query($connection, $query);
                 
                                                while($row = mysqli_fetch_assoc($select_commen)){
                                               $post_id =$row['post_id'];
                                               $post_title =$row['post_title'];
                                                 echo "<td><a href='../post.php?p_id=$post_id'>$post_title</a></td>";
                                                  }
                                           
                                              
                                               echo "<td><a href='comment.php?approved={$comment_id}'><i class='fa fa-check'></i></a></td>";
                                               echo "<td><a href='comment.php?unapproved={$comment_id}'><i class='fa fa-ban'></i></a></td>"; 
                                               echo "<td><a href='comment.php?deletecomment={$comment_id}'><i class='fa fa-close'></i></a></td>"; 
                                            echo "<td><a href='comment.php?source=updatecomment&p_id={$comment_id}'><i class='fa fa-pencil'></i></a></td>"; 
                                                
                                               echo "<tr>";
                                           }           
}

function queryConfirm($result){
    global $connection;
 if(!$result){
        
        die("Query Failed  ".mysqli_error($connection));
    }
    
}

function deletecat(){
    global $connection;
     if(isset($_GET['delete'])){
                            $the_cat_id = $_GET['delete'];
                            
                            $query="DELETE FROM categories WHERE id={$the_cat_id}";
                            $delete_query=mysqli_query($connection, $query);
                            header("Location: categories.php");
                        }
                        
}



function deletepost(){
    global $connection;
     if(isset($_GET['delete'])){
                            $the_post_id = $_GET['delete'];
                            
                            $query="DELETE FROM post WHERE post_id={$the_post_id}";
                            $post_query=mysqli_query($connection, $query);
                            header("Location: post.php");
                        }
                        
}
                                                            
function deleteuser(){
    global $connection;
     if(isset($_GET['delete'])){
                            $the_user_id = $_GET['delete'];
                            
                            $query="DELETE FROM users WHERE user_id={$the_user_id}";
                            $del_user_query=mysqli_query($connection, $query);
                            header("Location: user.php");
                        }
                        
}


function deletecomment(){
    global $connection;
     if(isset($_GET['deletecomment'])){
                            $the_comment_id = $_GET['deletecomment'];
                            
                            $query="DELETE FROM comments WHERE comment_id={$the_comment_id}";
                            $comment_query=mysqli_query($connection, $query);
                            header("Location: comment.php");
                        }
                        
}


function unapprovecomment(){
    global $connection;
     if(isset($_GET['unapproved'])){
                            $the_comment_id = $_GET['unapproved'];
                            
                            $query="UPDATE comments SET comment_status ='Unapproved' WHERE comment_id=$the_comment_id";
                            $unapprove_query=mysqli_query($connection, $query);
                            header("Location: comment.php");
                        }
                        
}

function approvecomment(){
    global $connection;
     if(isset($_GET['approved'])){
                            $the_comment_id = $_GET['approved'];
                            
                            $query="UPDATE comments SET comment_status ='Approved' WHERE comment_id=$the_comment_id";
                            $approve_query=mysqli_query($connection, $query);
                            header("Location: comment.php");
                        }
                        
}



function makeAdmin(){
    global $connection;
     if(isset($_GET['makeadmin'])){
                            $the_user_id = $_GET['makeadmin'];
                            
                            $query="UPDATE users SET user_role ='Admin' WHERE user_id=$the_user_id";
                            $makeadmin_query=mysqli_query($connection, $query);
                            header("Location: user.php");
                        }
                        
}

function makeSubscriber(){
    global $connection;
     if(isset($_GET['makesubscriber'])){
                            $the_user_id = $_GET['makesubscriber'];
                            
                            $query="UPDATE users SET user_role ='Subscriber' WHERE user_id=$the_user_id";
                            $makesubscriber_query=mysqli_query($connection, $query);
                            header("Location: user.php");
                        }
                        
}




function login(){
}

?>