
                   <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Image</th>
                            <th>Username</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>About User</th>
                            <th>E-mail</th>
                            <th> Role</th>
                            <th><i class="fa fa-check"></i></th>
                            <th><i class="fa fa-ban"></i></th>
                            <th><i class="fa fa-close"></i></th>
                            <th><i class="fa fa-pencil"></i></th>
                        </tr>
                    </thead>
                    <tbody>
                       <!--FIND ALL CATEGORY-->
                       <?php finduser(); ?>
                                           
                                           <!--DELETE QUERY-->
                                           <?php deleteuser(); ?>
                                           
                                           <?php makeAdmin(); ?>
                                           <?php makeSubscriber(); ?>
                                           
                                           
                                           
                        </tbody>
                </table>