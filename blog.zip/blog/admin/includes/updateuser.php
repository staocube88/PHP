  <?php
                        if(isset($_GET['p_id'])){
                        $the_user_id =$_GET['p_id'];
                        }
                   $query="SELECT * FROM users WHERE user_id='$the_user_id'";
    $selectp_user_query = mysqli_query($connection, $query);
                 
                                           while($row = mysqli_fetch_assoc($selectp_user_query)){
                                               $user_id =$row['user_id'];
                                               $username =$row['username'];
                                               $password =$row['password'];
                                               $user_fname =$row['user_fname'];
                                               $user_lname =$row['user_lname'];
                                               $user_desc =substr($row['user_desc'], 0, 100);
                                               $user_email =$row['user_email'];
                                               $user_image =$row['user_image'];  
                                               $user_role =$row['user_role'];
                                               $randSalt =$row['randSalt'];
                                           }
                                                                                        
                                           if(isset($_POST['updateuser'])){ 
                                           //  $post_category_id =$_POST['post_category'];
                                $username =$_POST['username'];
                                 $password =$_POST['password'];
                                 $user_fname =$_POST['user_fname'];
                                 $user_lname =$_POST['user_lname'];
                                 $user_desc =$_POST['user_desc'];
                                 $user_email =$_POST['user_email'];
                                 $user_image =$_FILES['user_image']['name'];
                                 $user_image_temp =$_FILES['user_image']['tmp_name']; 
                                 $user_role =$_POST['user_role'];
                                // $randSalt =$_POST['randSalt'];
                                                 
    move_uploaded_file($user_image_temp, "../assets/img/user/$user_image");
//    $hashFormat="$2y$10$";
//$salt="qwertyaiuygghuhiuiuiotmnb94";
//$hashF_and_salt=$hashFormat.$salt;
//$password=crypt($password,$hashF_and_salt);
                                               
                                    if(empty($user_image)) {
                                       $query="SELECT * FROM users WHERE user_id=$the_user_id";
                                        $selectp_image=mysqli_query($connection, $query);
                                        while($row =mysqli_fetch_array($selectp_image))
                                        {
                                            $user_image = $row['user_image'];
                                        }
                                                                  
                                        
                                    }          
                                    
                                            $query="
                                            UPDATE users 
                                            SET user_id='$the_user_id',
                                                username ='$username',
                                                password ='$password',
                                                user_fname ='$user_fname',
                                                user_lname ='$user_lname',
                                                user_desc ='$user_desc',
                                                user_email ='$user_email',
                                                user_image ='$user_image',
                                                user_role ='$user_role'
                                               WHERE user_id = '$the_user_id'";
                            $updateu_post_query=mysqli_query($connection, $query);
                           // header("Location: user.php");
                            queryConfirm($updateu_post_query);
                            
                                            //   if(!$update_post_query){
                                             //      die("Query Failed".mysqli_error($connection));
                                            //   }
                                               
                        }
                                              
                        
                        ?>                          
                    
                 
                   

                      <form action="" method="post" enctype="multipart/form-data">                  
                  
                  <div class="form-group">
                        <label for="post_date">First Name</label>
                    <input class="form-control" type="text" value="<?php echo $user_fname;?>" name="user_fname">
                    </div>
                     <div class="form-group">
                        <label for="post_date">Last Name</label>
                    <input class="form-control" type="text" value="<?php echo $user_lname;?>" name="user_lname">
                    </div>
                   
                    <div class="form-group">
                        <label for="username">Username</label>
                    <input class="form-control" type="text" value="<?php echo $username;?>" name="username">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                    <input class="form-control" type="password" value="<?php echo $password;?>" name="password">
                    </div>
                    <div class="form-group">
                        <label for="user_role">Edit User</label>
                   <select name="user_role" id="">
                           <option value="Subscriber"> <?php echo $user_role; ?></option> 
                                      
                            <option value="Admin"> Admin</option> 
                            <option value="Subscriber"> Subscriber</option>                
                        </select>            
                    </div>
                    
                    <div class="form-group">
                        <label for="post_content">About User</label>
                        <textarea class="form-control" id="" cols="30" rows="10" name="user_desc" ><?php echo $user_desc;?></textarea>
                    </div>
                     <div class="form-group">
                        <label for="user_email">Email Address </label>
                    <input class="form-control" type="email" value="<?php echo $user_email;?>" name="user_email">
                    </div>
                    <div class="form-group">
                        <label for="user_image">User Image</label>
                    <img src="../assets/img/user/<?php echo $user_image;?>" alt="Post Image" width="100">
                    <input class="form-control" type="file" name="user_image">
                    </div> 
                  
                    <div class="form-group">
                        <input class="btn btn-primary" type="submit" name="updateuser" value="Update User">
                    </div>            
                    </form>
                    
                <!--   
                   
                    -->
                 