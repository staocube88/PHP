<?php  session_start();?>
<?php 
  // global $connection;
    
 

             $_SESSION['username'] = null;
             $_SESSION['user_fname'] = null;
             $_SESSION['user_lname'] = null;
             $_SESSION['user_role'] = null;
            
header("Location: ../index.php");
      
?>


