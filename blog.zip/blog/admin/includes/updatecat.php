
                    
                    
                      <form action="" method="post">
                    <div class="form-group">
                        <label for="cat_title">Update Category</label>
                        
                        <?php
                        if(isset($_GET['update'])){
                        $cat_id =$_GET['update'];
                        
                      $query="SELECT * FROM categories WHERE id =$cat_id";
                $select_cat = mysqli_query($connection, $query);
                 
                                           while($row = mysqli_fetch_assoc($select_cat)){
                                               $cat_id =$row['id'];
                                               $cat_title =$row['cat_title'];
                                                                                       
                                               ?>
                                                
                                                <input value="<?php if(isset($cat_title)){ echo $cat_title;}?>" class="form-control" type="text" name="cat_title">
                                                 
                                         <?php  }   } ?> 
                                    <!-- //Update code-->    
                                         <?php
                        
                        if(isset($_POST['update'])){
                            $cat_title = $_POST['cat_title'];
                            
                            $query="UPDATE categories SET cat_title='{$cat_title}' WHERE id={$cat_id}";
                            $update_query=mysqli_query($connection, $query);
                            header("Location: categories.php");
                             if(!update_query){
                                die('Query Failed '.mysqli_error($connection));
                                
                            }
                            
                        }
                        
                        
                        ?>                          
                    
                    </div>
                    <div class="form-group">
                        <input class="btn btn-primary" type="submit" name="update" value="Update Category">
                    </div>            
                    </form>
                     