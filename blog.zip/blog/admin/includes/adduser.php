
<?php
if(isset($_POST['createuser'])){
                                // $user_id =$_POST['user_id'];
                                 $username =$_POST['username'];
                                 $password =$_POST['password'];
                                 $user_fname =$_POST['user_fname'];
                                 $user_lname =$_POST['user_lname'];
                                 $user_desc =$_POST['user_desc'];
                                 $user_email =$_POST['user_email'];
                                 $user_image =$_FILES['user_image']['name'];
                                 $user_image_temp =$_FILES['user_image']['tmp_name']; 
                                 $user_role =$_POST['user_role'];
                                // $randSalt =$_POST['randSalt'];
                                                 
    move_uploaded_file($user_image_temp, "../assets/img/user/$user_image");
 //   $hashFormat="$2y$10$";
//$salt="qwertyaiuygghuhiuiuiotmnb94";
//$hashF_and_salt=$hashFormat.$salt;
//$password=crypt($password,$hashF_and_salt);
    
    $query="INSERT INTO users (username, password, user_fname, user_lname, user_desc, user_email, user_image, user_role) ";
    $query .="VALUES ('{$username}','{$password}','{$user_fname}','{$user_lname}','{$user_desc}','{$user_email}','{$user_image}','{$user_role}')"; 
    
    $createuser_query=mysqli_query($connection, $query);
    
   queryConfirm($createuser_query);
}

?> 
                   
                   
                   <form action="" method="post" enctype="multipart/form-data">
                   
                  <div class="form-group">
                        <label for="post_date">First Name</label>
                    <input class="form-control" type="text" name="user_fname">
                    </div>
                     <div class="form-group">
                        <label for="post_date">Last Name</label>
                    <input class="form-control" type="text" name="user_lname">
                    </div>
                   
                    <div class="form-group">
                        <label for="post_title">Username</label>
                    <input class="form-control" type="text" name="username">
                    </div>
                    <div class="form-group">
                        <label for="post_author">Password</label>
                    <input class="form-control" type="password" name="password">
                    </div>
                     <div class="form-group">
                   <select name="user_role" id="">
                        <option value="Subscriber">Select Options</option>
                         <option value="Admin">Admin</option>
                        <option value="Subscriber">Subscriber</option>
                   </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="post_content">About User</label>
                        <textarea class="form-control" id="" cols="30" rows="10" name="user_desc"></textarea>
                    </div>
                     <div class="form-group">
                        <label for="post_date">Email Address </label>
                    <input class="form-control" type="email" name="user_email">
                    </div>
                    <div class="form-group">
                        <label for="post_image">User Image</label>
                    <input class="form-control" type="file" name="user_image">
                    </div> 
                  
                    <div class="form-group">
                        <input class="btn btn-primary" type="submit" name="createuser" value="Add New User">
                    </div>            
                    </form>