
                   <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Author</th>
                            <th>Image</th>
                             <th>Content</th>
                            <th>Tags</th>
                            <th>Status</th>
                            <th> Views</th>
                            <th>Date</th>
                            <th><i class="fa fa-close"></i></th>
                            <th><i class="fa fa-pencil"></i></th>
                        </tr>
                    </thead>
                    <tbody>
                       <!--FIND ALL CATEGORY-->
                       <?php findpost(); ?>
                                           
                                           <!--DELETE QUERY-->
                                           <?php deletepost(); ?>
                                      
                                           
                        </tbody>
                </table>