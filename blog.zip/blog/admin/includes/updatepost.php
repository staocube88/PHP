  <?php
                        if(isset($_GET['p_id'])){
                        $the_post_id =$_GET['p_id'];
                        }
                  $query="SELECT * FROM post WHERE post_id='$the_post_id'";
                $select_post = mysqli_query($connection, $query);
                 
                                           while($row = mysqli_fetch_assoc($select_post)){
                                               $the_post_id =$row['post_id'];
                                               $post_title =$row['post_title'];
                                               $post_author =$row['post_author'];
                                               $post_image =$row['post_image'];
                                               $post_content =$row['post_content'];
                                               $post_type =$row['post_type'];
                                               $post_tag =$row['post_tag'];
                                               $post_status =$row['post_status'];
                                               $post_view =$row['post_view'];
                                               $post_date =$row['post_date'];
                                           }
                                                                                        
                                           if(isset($_POST['updatepost'])){ 
                                             $post_category_id =$_POST['post_category'];
                                               $post_title =$_POST['post_title'];
                                               $post_author =$_POST['post_author'];
                                               $post_image =$_FILES['post_image']['name'];
                                               $post_image_temp =$_FILES['post_image']['tmp_name'];
                                               $post_content =$_POST['post_content'];
                                               $post_tag =$_POST['post_tag'];
                                               $post_status =$_POST['post_status'];
                                               $post_type =$_POST['post_type'];
                                                $post_date =date('d-m-y');
    
    move_uploaded_file($post_image_temp, "../assets/img/news/$post_image");
                                    if(empty($post_image)) {
                                       $query="SELECT * FROM post WHERE post_id=$the_post_id";
                                        $select_image=mysqli_query($connection, $query);
                                        while($row =mysqli_fetch_array($select_image))
                                        {
                                            $post_image = $row['post_image'];
                                        }
                                                                  
                                        
                                    }          
                                    
                                            $query="
                                            UPDATE post 
                                            SET post_cat_id='$post_category_id',
                                                post_title ='$post_title',
                                                post_author ='$post_author',
                                                post_image ='$post_image',
                                                post_content ='$post_content',
                                                post_tag ='$post_tag',
                                                post_status ='$post_status',
                                                post_type ='$post_type',
                                                post_date ='$post_date}'
                                               WHERE post_id = '$the_post_id'";
                            $update_post_query=mysqli_query($connection, $query);
                          //  header("Location: post.php");
                            queryConfirm($update_post_query);
                            
                                            //   if(!$update_post_query){
                                             //      die("Query Failed".mysqli_error($connection));
                                            //   }
                                               
                        }
                                              
                        
                        ?>                          
                    
                 
                   

                     <form action="" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="post_cat_id">Post Category Id</label>
                   <select name="post_category" id="">
                       <?php
                       
                        $query="SELECT * FROM categories";
                $select_cate = mysqli_query($connection, $query);
                             queryConfirm($select_cate);            
                                           while($row = mysqli_fetch_assoc($select_cate)){
                                               $cat_id =$row['id'];
                                               $cat_title =$row['cat_title'];
                                            
                                               echo "<option value='$cat_id'>{$cat_title}</option>";  
                                               
                                           }
                        ?>
                   </select>
                    </div>
                    <div class="form-group">
                        <label for="post_title">Post Title</label>
                    <input class="form-control" type="text" name="post_title" value="<?php echo $post_title?>">
                    </div>
                    <div class="form-group">
                        <label for="post_author">Post Author</label>
                    <input class="form-control" type="text" name="post_author" value="<?php echo $post_author;?>">
                    </div>
                    <div class="form-group">
                        <label for="post_date">Post Date</label>
                    <input class="form-control" type="date" name="post_date" value="<?php echo $post_date;?>">
                    </div>
                    <div class="form-group">
                        <label for="post_image">Post Image</label>
                    <img src="../assets/img/news/<?php echo $post_image;?>" alt="Post Image" width="100">
                    <input class="form-control" type="file" name="post_image">
                    </div> 
                    <div class="form-group">
                        <label for="post_content">Post Content</label>
                        <textarea class="form-control" id="" cols="30" rows="10" name="post_content" value="<?php echo $post_content;?>"><?php echo $post_content;?></textarea>
                    </div>
                     <div class="form-group">
                        <label for="post_tag">Post Tag</label>
                    <input class="form-control" type="text" name="post_tag" value="<?php echo $post_tag;?>">
                    </div>
                     <div class="form-group">
                        <label for="post_type">Post Type</label>
                    <input class="form-control" type="text" name="post_type" placeholder="Trending/Recent/Weekly/Flash" value="<?php echo $post_type;?>">
                    </div>
                    <div class="form-group">
                        <label for="post_status">Post Status</label>
                    <input class="form-control" type="text" name="post_status" placeholder="Draft/Publish" value="<?php echo $post_status;?>">
                    </div>
                                      
                    <div class="form-group">
                        <input class="btn btn-primary" type="submit" name="updatepost" value="Update Post">
                    </div>            
                    </form>