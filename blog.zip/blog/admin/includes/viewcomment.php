
                   <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Image</th>
                            <th>Author</th>
                            <th>Content</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th> In Response to</th>
                            <th> Approve</th>
                            <th> Unapprove</th>
                            <th><i class="fa fa-close"></i></th>
                            <th><i class="fa fa-pencil"></i></th>
                        </tr>
                    </thead>
                    <tbody>
                       <!--FIND ALL CATEGORY-->
                       <?php findcomment(); ?>
                                           
                                           <!--DELETE QUERY-->
                                           <?php deletecomment(); ?>
                                           
                                            <!--UNAPPROVE QUERY-->
                                           <?php unapprovecomment(); ?>
                                           
                                           <!--APPROVE QUERY-->
                                           <?php approvecomment(); ?>
                                      
                                           
                        </tbody>
                </table>