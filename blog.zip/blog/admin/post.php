<?php include "includes/admin_header.php" ?>
 
   <div class="page-container">
   <!--/content-inner-->
<div class="left-content">
	   <div class="mother-grid-inner">
             <!--header start here-->
				<?php include "includes/nav.php"?>
<!--heder end here-->
		<ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a> <i class="fa fa-angle-right"></i></li>
            </ol>
            
            
            
            <!--BODY begins-->
        <div class ="container-fluid">    
            <div class="col-xs-6">
             
             <?php
              if(isset($_GET['source'])){
              $source = $_GET['source'];
              
              }else{
              $source='';
              }
              switch($source){
              case 'addpost';
               include "includes/addpost.php";
              break;
              case 'updatepost';
             include "includes/updatepost.php";
              break;
              case '200';
              echo "NICE 200";
              break;
              
              default;
              
              // code here
              include "includes/viewpost.php";
              
              break;
              }




              ?>
              
             
           </div>
            
                   
           </div>
            
            
            
            
            
            
            
            
            
            
            
            
            
                        <!--BODY ends-->

	  <!--//w3-agileits-pane-->	
<!-- script-for sticky-nav -->
		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop(); 
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });
			 
		});
		</script>
		<!-- /script-for sticky-nav -->
<!--inner block start here-->
<div class="inner-block">

</div>
<!--inner block end here-->
<!--copy rights start here-->

<!--COPY rights end here-->
</div>
</div>
  <!--//content-inner-->
			<!--/sidebar-menu-->
				
                          <?php include "includes/sidebar.php"?>
                          
                          
							  <div class="clearfix"></div>		
							</div>
							<script>
							var toggle = true;
										
							$(".sidebar-icon").click(function() {                
							  if (toggle)
							  {
								$(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
								$("#menu span").css({"position":"absolute"});
							  }
							  else
							  {
								$(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
								setTimeout(function() {
								  $("#menu span").css({"position":"relative"});
								}, 400);
							  }
											
											toggle = !toggle;
										});
							</script>
<!--js -->
<?php include "includes/admin_footer.php" ?>