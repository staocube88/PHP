<?php
                
                if(isset($_GET['p_id']))
                {
                    $te_post_cat_id=$_GET['p_id'];
                }
                
                $query="SELECT COUNT * FROM post WHERE post_id =$te_post_cat_id";
                $select_count = mysqli_query($connection, $query);
                while($row = mysqli_fetch_assoc($select_count)){
                             $te_post_cat_id =$row['post_cat_id'];     
                            echo "<p>{$te_post_cat_id}</p>";
                         
                         }
                         ?>